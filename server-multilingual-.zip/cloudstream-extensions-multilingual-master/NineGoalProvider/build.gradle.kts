version = 6

cloudstream {
    description = ""
    authors = listOf( "ImZaw" )

    status = 1

    tvTypes = listOf( "Live" )

    iconUrl = "https://media.discordapp.net/attachments/1027568249900109875/1046110428402561025/JK8J1KX.png?width=%size%&height=%size%"
}
